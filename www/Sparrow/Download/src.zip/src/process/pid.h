void initialize_pid();

int allocate_pid();

void free_pid(int pid);
