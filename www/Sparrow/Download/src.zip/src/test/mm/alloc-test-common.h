#ifndef _ALLOC_TEST_COMMON_H_
#define _ALLOC_TEST_COMMON_H_

void alloc_test_case_init_common();
int is_page_allocator_restored();
void record_state_of_allocator();

#endif /* _ALLOC_TEST_COMMON_H_ */
