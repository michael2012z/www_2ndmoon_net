#ifndef _TIME_H_
#define _TIME_H_

struct timespec {
	long	tv_sec;			/* seconds */
	long   	tv_nsec;		/* nanoseconds */
};

#endif
