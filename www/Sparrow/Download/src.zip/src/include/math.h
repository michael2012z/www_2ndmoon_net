#ifndef _MATH_H_
#define _MATH_H_

#define _order_of(n) (1 << n)

#define math_abs(n) (((n)>0)?(n):(-(n)))

#endif
