#include <stdio.h>
#include <stdlib.h>

void main() {
  int i,j;
  char *p;
  i = 0x11223344;
  j = 0xaabbccdd;

  printf("%x 77777777777777777777777777777777777777777\n", i);

  i = 0xaaaaaaaa;
  j = 0xcccccccc;

}
