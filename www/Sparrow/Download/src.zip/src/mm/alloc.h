#ifndef _ALLOC_H_
#define _ALLOC_H_

#include "bootmem.h"
#include "page_alloc.h"
#include "slab_alloc.h"

#endif /* _ALLOC_H_ */
