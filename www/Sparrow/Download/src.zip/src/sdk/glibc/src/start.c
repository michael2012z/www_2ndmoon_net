#include "../inc/stdlib.h"

extern void main();

void _start () {
  main();
  exit(0);
}
