#include <date.h>

/* not supported */
date_t date_parse_format_iso(char *str) {
  date_t date;
  return date;
}
