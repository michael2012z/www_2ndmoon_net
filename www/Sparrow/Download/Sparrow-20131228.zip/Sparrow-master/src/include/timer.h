
#ifndef _TIMER_H_
#define _TIMER_H_

void arm_init_timer();
void init_timer();
void on_timer();

#endif
