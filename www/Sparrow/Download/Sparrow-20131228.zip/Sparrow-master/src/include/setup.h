#ifndef _SETUP_H_
#define _SETUP_H_

void arm_cpu_reset();
void arm_cpu_init();

#endif /* _SETUP_H_ */
