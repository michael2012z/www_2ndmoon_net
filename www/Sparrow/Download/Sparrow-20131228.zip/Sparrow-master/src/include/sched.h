#ifndef _SCHED_H_
#define _SCHED_H_

#include <memory.h>
#include <process.h>

#endif
