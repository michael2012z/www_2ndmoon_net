#include <stdio.h>
#include <stdlib.h>

int main() {
  int i,j;
  char *p;
  i = 0x11223344;
  j = 0xaabbccdd;

  printf("%d 5555555555555555555555555555555555555\n", i);
  p = (char *)malloc(16);

  i = 0xaaaaaaaa;
  j = 0xcccccccc;

  while(1);
  return 0;
}
