#include <stdio.h>
#include <stdlib.h>

void main() {
  printf("888888888888888888888888888888888888888888\n");
  sleep(100);
  printf("888888 88888888 8888888 8888888888 8888888\n");
}
