
void main() {
  int i,j;
  i = 0x11223344;
  j = 0xaabbccdd;
  while(1);
}
